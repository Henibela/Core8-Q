Opcode (Hex),Instruction,Description
0x0,"ADD dest, src","dest += src, flags"
0x1,"SUB dest, src","dest -= src, flags"
0x2,"AND dest, src","dest &= src, flags"
0x3,"OR dest, src","dest |= src, flags"
0x4,NOT dest,"dest = ~dest, flags (src ignored)"
0x5,SHL dest,"dest <<= 1, flags (src ignored)"
0x6,"LOAD dest, [addr]",dest = mem[addr]
0x7,"STORE src, [addr]",mem[addr] = src
0x8,BZ [addr],"If Z, PC = addr"
0x9,BN [addr],"If N, PC = addr"
0xA,BO [addr],"If O, PC = addr"
0xB,JMP [addr],PC = addr